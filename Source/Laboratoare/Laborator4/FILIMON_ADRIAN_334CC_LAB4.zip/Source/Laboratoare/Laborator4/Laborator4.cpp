#include "Laborator4.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>
#include "Transform3D.h"

using namespace std;

/*
To translate the first cube press LEFT_CTRL + W A S D R F

*/
Laborator4::Laborator4()
{
}

Laborator4::~Laborator4()
{
}

void Laborator4::Init()
{
	polygonMode = GL_FILL;

	Mesh* mesh = new Mesh("box");
	mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
	meshes[mesh->GetMeshID()] = mesh;

	// initialize tx, ty and tz (the translation steps)
	translateX = 0;
	translateY = 0;
	translateZ = 0;

	// initialize sx, sy and sz (the scale factors)
	scaleX = 1;
	scaleY = 1;
	scaleZ = 1;
	
	// initialize angularSteps
	angularStepOX = 0;
	angularStepOY = 0;
	angularStepOZ = 0;
}

void Laborator4::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}
float limit_tr = 600.f;
float limit_sc = 300.f;
float limit_rot = 600.f;
int tog_tr = 0;
int tog_sc = 0;
int tog_rot = 0;
float range_tr = limit_tr;
float range_sc = limit_sc;
float range_rot = limit_rot;

void Laborator4::Update(float deltaTimeSeconds)
{
	glLineWidth(3);
	glPointSize(5);
	glPolygonMode(GL_FRONT_AND_BACK, polygonMode);

	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(-2.5f, 0.5f,-1.5f);
	if (tog_tr) {
		translateX += deltaTimeSeconds;
		range_tr--;
	}
	else {
		translateX -= deltaTimeSeconds;
		range_tr--;
	}
	if (range_tr == 0) {
		tog_tr = !tog_tr;
		range_tr = limit_tr;
	}
	modelMatrix *= Transform3D::Translate(translateX, translateY, translateZ);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);
	if (tog_sc) {
		scaleX += deltaTimeSeconds;
		scaleY += deltaTimeSeconds;
		scaleZ += deltaTimeSeconds;
		range_sc--;
	}
	else {
		scaleX -= deltaTimeSeconds;
		scaleY -= deltaTimeSeconds;
		scaleZ -= deltaTimeSeconds;
		range_sc--;
	}
	if (range_sc == 0) {
		tog_sc = !tog_sc;
		range_sc = limit_sc;
	}

	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(0.0f, 0.5f, -1.5f);

	modelMatrix *= Transform3D::Scale(scaleX, scaleY, scaleZ);
	RenderMesh(meshes["box"], shaders["Simple"], modelMatrix);

	modelMatrix = glm::mat4(1);
	modelMatrix *= Transform3D::Translate(2.5f, 0.5f, -1.5f);
	if (tog_rot) {
		angularStepOX += deltaTimeSeconds;
		angularStepOY += deltaTimeSeconds;
		angularStepOZ += deltaTimeSeconds;
		range_rot--;
	}
	else {
		angularStepOX -= deltaTimeSeconds;
		angularStepOY -= deltaTimeSeconds;
		angularStepOZ -= deltaTimeSeconds;
		range_rot--;
	}
	if (range_rot == 0) {
		tog_rot = !tog_rot;
		range_rot = limit_rot;
	}
	modelMatrix *= Transform3D::RotateOX(angularStepOX);
	modelMatrix *= Transform3D::RotateOY(angularStepOY);
	modelMatrix *= Transform3D::RotateOZ(angularStepOZ);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);


}

void Laborator4::FrameEnd()
{
	DrawCoordinatSystem();
}

void Laborator4::OnInputUpdate(float deltaTime, int mods)
{
	if (window->KeyHold(GLFW_KEY_LEFT_CONTROL)){

		if (window->KeyHold(GLFW_KEY_W)) {
			translateZ -= deltaTime * SPEEDUP;
		}
		if (window->KeyHold(GLFW_KEY_A)) {
			translateX -= deltaTime * SPEEDUP;
		}
		if (window->KeyHold(GLFW_KEY_S)) {
			translateZ += deltaTime * SPEEDUP;
		}
		if (window->KeyHold(GLFW_KEY_D)) {
			translateX += deltaTime * SPEEDUP;
		}
		if (window->KeyHold(GLFW_KEY_R)) {
			translateY += deltaTime * SPEEDUP;
		}
		if (window->KeyHold(GLFW_KEY_F)) {
			translateY -= deltaTime * SPEEDUP;
		}
	}

	if (window->KeyHold(GLFW_KEY_1)) {
		scaleX += deltaTime * SPEEDUP;
		scaleY += deltaTime * SPEEDUP;
		scaleZ += deltaTime * SPEEDUP;
	}
	if (window->KeyHold(GLFW_KEY_2)) {
		scaleX -= deltaTime * SPEEDUP;
		scaleY -= deltaTime * SPEEDUP;
		scaleZ -= deltaTime * SPEEDUP;
	}
	if (window->KeyHold(GLFW_KEY_3)) {
		angularStepOX += deltaTime * SPEEDUP;
	}
	if (window->KeyHold(GLFW_KEY_4)) {
		angularStepOX -= deltaTime * SPEEDUP;
	}
	if (window->KeyHold(GLFW_KEY_5)) {
		angularStepOY += deltaTime * SPEEDUP;
	}
	if (window->KeyHold(GLFW_KEY_6)) {
		angularStepOY -= deltaTime * SPEEDUP;
	}
	if (window->KeyHold(GLFW_KEY_7)) {
		angularStepOZ += deltaTime * SPEEDUP;
	}
	if (window->KeyHold(GLFW_KEY_8)) {
		angularStepOZ -= deltaTime * SPEEDUP;
	}
}

void Laborator4::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_SPACE)
	{
		switch (polygonMode)
		{
		case GL_POINT:
			polygonMode = GL_FILL;
			break;
		case GL_LINE:
			polygonMode = GL_POINT;
			break;
		default:
			polygonMode = GL_LINE;
			break;
		}
	}
}

void Laborator4::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Laborator4::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Laborator4::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Laborator4::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator4::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator4::OnWindowResize(int width, int height)
{
}
