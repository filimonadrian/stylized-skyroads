# pragma once

#include <iostream>
#include <random>

float generateFloat(float rangeFrom, float rangeTo);
int generateInt(int rangeFrom, int rangeTo);